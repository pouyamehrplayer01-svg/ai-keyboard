package com.example.aikeyboard

import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AiKeyboardIME : InputMethodService() {

    private val job = Job()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val aiClient = AiSuggestionClient()

    private lateinit var suggestion1: TextView
    private lateinit var suggestion2: TextView
    private lateinit var suggestion3: TextView

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.keyboard_view, null)

        suggestion1 = view.findViewById(R.id.suggestion_1)
        suggestion2 = view.findViewById(R.id.suggestion_2)
        suggestion3 = view.findViewById(R.id.suggestion_3)

        listOf(suggestion1, suggestion2, suggestion3).forEach { tv ->
            tv.setOnClickListener {
                val text = tv.text.toString()
                if (text.isNotBlank()) {
                    currentInputConnection?.commitText(text, 1)
                }
            }
        }

        return view
    }

    /**
     * وقتی کیبورد باز می‌شود، بر اساس متنِ همین فیلد تایپ (که IME طبق
     * استاندارد اندروید از قبل بهش دسترسی داره — بدون نیاز به Accessibility)
     * سه پیشنهاد از سرور می‌گیریم.
     */
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadSuggestions()
    }

    private fun loadSuggestions() {
        // فیلدهای حساس (پسورد و...) را نادیده می‌گیریم
        val inputType = currentInputEditorInfo?.inputType ?: 0
        val variation = inputType and InputType.TYPE_MASK_VARIATION
        val isPassword =
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        if (isPassword) {
            displaySuggestions(emptyList())
            return
        }

        val textBefore = currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: ""
        val textAfter = currentInputConnection?.getTextAfterCursor(200, 0)?.toString() ?: ""

        scope.launch {
            val suggestions = aiClient.getSuggestions(textBefore, textAfter)
            displaySuggestions(suggestions)
        }
    }

    private fun displaySuggestions(suggestions: List<String>) {
        val views = listOf(suggestion1, suggestion2, suggestion3)
        views.forEachIndexed { index, tv ->
            tv.text = suggestions.getOrNull(index) ?: ""
            tv.visibility = if (suggestions.getOrNull(index) != null) View.VISIBLE else View.INVISIBLE
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }
}
