package com.example.aikeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.explanation_text).text =
            "این کیبورد هنگام تایپ، بر اساس همان متنی که می‌نویسید، ۳ پیشنهاد پاسخ هوشمند نمایش می‌دهد. " +
            "برای فعال‌سازی، روی دکمه زیر بزن و کیبورد «AI Keyboard» را انتخاب کن."

        findViewById<Button>(R.id.enable_keyboard_button).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
    }
}
