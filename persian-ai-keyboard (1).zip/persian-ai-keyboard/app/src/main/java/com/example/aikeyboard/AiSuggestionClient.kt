package com.example.aikeyboard

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * این کلاینت هرگز مستقیماً به API مدل (OpenAI/Claude/...) وصل نمی‌شود.
 * درعوض به یک سرور واسط (proxy) خودت وصل می‌شود که کلید API آنجا امن نگه‌داری می‌شود.
 *
 * BASE_URL را با آدرس سرور واسط خودت جایگزین کن.
 */
class AiSuggestionClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "https://YOUR-PROXY-SERVER.example.com/suggest"

    /**
     * textBefore: متن قبل از مکان‌نمای فعلی در همین فیلد تایپ
     * textAfter: متن بعد از مکان‌نمای فعلی (در صورت وجود)
     *
     * خروجی: لیستی از حداکثر ۳ پیشنهاد. اگر شبکه در دسترس نبود، لیست خالی برمی‌گردد.
     */
    suspend fun getSuggestions(textBefore: String, textAfter: String): List<String> =
        withContext(Dispatchers.IO) {
            try {
                val body = JSONObject().apply {
                    put("text_before", textBefore)
                    put("text_after", textAfter)
                    put("num_suggestions", 3)
                }.toString().toRequestBody("application/json".toMediaType())

                val request = Request.Builder()
                    .url(baseUrl)
                    .post(body)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val json = JSONObject(response.body?.string() ?: return@withContext emptyList())
                    val arr: JSONArray = json.optJSONArray("suggestions") ?: return@withContext emptyList()
                    (0 until arr.length()).map { arr.getString(it) }
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
}
